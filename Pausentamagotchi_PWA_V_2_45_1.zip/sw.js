// Pausentamagotchi - Service Worker
// Strategie: cache-first. Die App ist komplett statisch, es gibt keinen Server
// und keine API. Alles wird bei der Installation gecacht und danach offline
// ausgeliefert. Spielstaende liegen ausschliesslich im localStorage.
const CACHE = 'pausentama-v2.45.1';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/fonts.css',
  './css/styles.css',
  './js/01-storage-core.js',
  './js/02-data-shop.js',
  './js/03-backup.js',
  './js/04-i18n.js',
  './js/05-shop-logic.js',
  './js/06-gamefeel-level.js',
  './js/07-arena-endgame.js',
  './js/08-graves-ambient.js',
  './js/09-quests-village.js',
  './js/10-core-loop.js',
  './js/11-arcade.js',
  './js/12-extras.js',
  './js/13-boot.js',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;

  // Seitenaufrufe: erst Netz (fuer Updates), sonst Cache. So bleibt die App
  // offline startfaehig, holt online aber neue Versionen.
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put('./index.html', copy));
          return res;
        })
        .catch(() => caches.match('./index.html').then(r => r || caches.match('./')))
    );
    return;
  }

  e.respondWith(
    caches.match(e.request).then(hit => {
      if (hit) return hit;
      return fetch(e.request).then(res => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      });
    })
  );
});
