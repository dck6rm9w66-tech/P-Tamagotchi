# Pausentamagotchi

Ein Tamagotchi für die Arbeitspause. Dein Wolkenwesen besucht dich jeden Tag
für 30 Minuten aktiver Bildschirmzeit — und erinnert dich nebenbei daran,
selbst mal aufzustehen.

Läuft vollständig im Browser, ohne Server und ohne Konto. Alle Spielstände
liegen im `localStorage` deines Geräts.

## Installation

1. Alle Dateien auf einen Webserver legen (Ordnerstruktur beibehalten!)
2. Seite im Browser öffnen
3. Über das Menü „Als App installieren" auf den Startbildschirm legen

Wichtig: Die App muss über **http(s)** ausgeliefert werden, nicht per
Doppelklick als `file://` — sonst blockiert der Browser Service Worker
und localStorage.

## Aufbau

```
index.html          Struktur der Oberfläche
css/
  styles.css        Gerät, Fenster, Animationen
  fonts.css         FontAwesome-Teilmenge (eingebettet, offlinefähig)
js/
  01-storage-core   Speicher-Helfer, IDs, Grundkonstanten, Tastatursteuerung
  02-data-shop      Ei-Farben, Arten, Shop-Artikel, Multiplikatoren, Buff-Dauern
  03-backup         Backup-Format, Prüfsumme, Sichern & Laden
  04-i18n           Sprachumschaltung und Wörterbücher (Deutsch/Englisch)
  05-shop-logic     Kaufen, Benutzen, Inventar, Glücksrad
  06-gamefeel-level Belohnungs-Animationen, Töne, Pfleger-Level, Freischaltungen
  07-arena-endgame  Arena, PvP, Mini-Bosse, Fernrohr & Vermächtnis
  08-graves-ambient Ahnengalerie, Grabpflege, Hintergrund-Ambiente, Raid, Bewertung
  09-quests-village Geschichte, Tages-Quests, Ergonomie, Tagebuch, Wolkendorf, Pomodoro
  10-core-loop      Spiel-Logik, Zustand, Rendern, Individualität
  11-arcade         Arcade-Automaten: Space Invaders, Pong, Defender
  12-extras         Dock-Hinweise, Schrittzähler, 8-Ball, Sprüche
  13-boot           Start der App, Speicher-Anforderung, Service Worker
sw.js               Service Worker (Offline-Betrieb)
manifest.webmanifest
*.png               App-Symbole
```

### Zur Reihenfolge der Skripte

Die Dateien sind **klassische Skripte** (keine Module) und teilen sich einen
gemeinsamen Namensraum. Die Nummerierung ist deshalb keine Kosmetik, sondern
die Ladereihenfolge: Konstanten und Daten müssen vorhanden sein, bevor der
Code sie benutzt, und `13-boot.js` startet zuletzt die App.

Wer eine Datei hinzufügt, trägt sie an der passenden Stelle in `index.html`
**und** in der Liste `ASSETS` in `sw.js` ein — sonst fehlt sie offline.

### Nach Änderungen

Die Versionsnummer in `sw.js` (`const CACHE`) hochzählen. Sonst liefert der
Service Worker den alten Stand aus dem Cache aus.

## Datenschutz

Es werden keinerlei Daten übertragen. Kein Tracking, keine Konten, keine
Server-Kommunikation. Der Austausch von Spielständen für Highscores und
Kämpfe läuft ausschließlich über Dateien, die du selbst weitergibst.

© Basti
