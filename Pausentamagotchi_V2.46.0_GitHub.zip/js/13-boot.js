/* Pausentamagotchi - Start der App, Speicher-Anforderung, Service Worker */
init();

// --- Sprites für das aktuelle Pet vorladen ---
// Verhindert Flackern beim Wechsel zwischen Wach-/Schlaf-/Wut-Darstellung.
try { preloadPetSprites(typeof pet !== 'undefined' ? pet : null); } catch (e) {}

// --- Dauerhafter Speicher (Android/Chrome & Desktop) ---
// Ohne dies darf der Browser den localStorage bei Speicherdruck raeumen.
// Ist die App installiert, gewaehrt Chrome die Anfrage meist automatisch.
// Safari/iOS kennt die API nicht -> wird still uebersprungen.
async function requestPersistentStorage() {
    try {
        if (!navigator.storage || !navigator.storage.persist) return;
        if (await navigator.storage.persisted()) return;
        await navigator.storage.persist();
    } catch (e) { /* nicht unterstuetzt - kein Problem */ }
}
requestPersistentStorage();

// --- PWA: Service Worker fuer den Offline-Betrieb registrieren ---
// Nur ueber http(s) moeglich; beim Oeffnen als lokale Datei still ignorieren.
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js').catch(err => {
            console.warn('Service Worker nicht registriert:', err);
        });
    });
}
// Aktive Ergonomie-Erinnerungen alle ~12 Minuten (Echtzeit) – funktioniert auch nach Abfahrt ins Wolkendorf
setInterval(() => { try { showErgoReminder(); } catch(e){} }, 1000 * 60 * 12);
